package com.tricon.kafka.dataAnalyticsconsumer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataAnalyticsConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DataAnalyticsConsumerApplication.class, args);
	}

}
